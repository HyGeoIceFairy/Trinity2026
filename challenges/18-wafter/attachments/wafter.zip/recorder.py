"""Flight-test material recorder. Restore the selected parts from parts.csv."""
import argparse,csv,hashlib,hmac,json,struct
from pathlib import Path
MASK=(1<<32)-1

def rotate(value):return ((value<<5)|(value>>27))&MASK

def load(folder):
    with (folder/'parts.csv').open(encoding='utf-8',newline='') as f:
        parts=[{'id':int(row['id']),'mass_mg':int(row['mass_mg']),'code':int(row['code_hex'],16)} for row in csv.DictReader(f)]
    if len(parts)!=42 or sorted(p['id'] for p in parts)!=list(range(1,43)):raise ValueError('Expected 42 distinct part numbers')
    if any(not 1<=p['mass_mg']<=10000000 or not 0<=p['code']<=MASK for p in parts):raise ValueError('Bad part record')
    return sorted(parts,key=lambda p:p['id']),json.loads((folder/'record.json').read_text(encoding='utf-8'))

def material(ids):return ','.join('%02d'%i for i in sorted(ids)).encode('ascii')

def restore(parts,record,ids):
    if any(type(i) is not int for i in ids) or len(set(ids))!=len(ids):raise ValueError('Part numbers must be distinct integers')
    table={p['id']:p for p in parts}
    if any(i not in table for i in ids):raise ValueError('Unknown part number')
    selected=sorted(ids)
    if len(selected)!=record['count']:raise ValueError('Part count does not match')
    if sum(table[i]['mass_mg'] for i in selected)!=record['mass_mg']:raise ValueError('Total mass does not match')
    check=record['initial']
    for i in selected:check=rotate(check)^table[i]['code']
    if check!=record['check']:raise ValueError('Assembly check does not match')
    envelope=record['letter']
    if envelope.get('version')!=1:raise ValueError('Unsupported record version')
    raw=bytes.fromhex(envelope['ciphertext']);tag=bytes.fromhex(envelope['tag'])
    key=hashlib.sha256(b'wafter-parts-v1\0'+material(selected)).digest()
    if not hmac.compare_digest(tag,hmac.digest(key,b'trinity-sealed-v1\0'+raw,'sha256')):raise ValueError('This is not the recorded assembly')
    stream=b''.join(hashlib.sha256(key+struct.pack('<I',i)).digest() for i in range((len(raw)+31)//32))
    return bytes(a^b for a,b in zip(raw,stream)).decode('ascii')

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('ids',help='comma-separated part numbers');p.add_argument('--data',type=Path,default=Path(__file__).resolve().parent);a=p.parse_args()
    try:
        parts,record=load(a.data);ids=[int(i) for i in a.ids.split(',')];print(restore(parts,record,ids))
    except (ValueError,KeyError,UnicodeError) as error:p.exit(1,str(error)+'\n')
