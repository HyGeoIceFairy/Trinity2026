"""Paper-03 host driver recovered from the repair-shop computer.

The panel starts white. One bit is one pixel: 1=black, 0=white.
Each row is packed from the most significant bit, padded to a whole byte.
Writes affect the backing memory; only refresh() changes the visible screen.
Coordinates are measured from the top-left corner.
"""
import struct

MAGIC = b"TAEINK1\n"
RECORD = struct.Struct("<BHHHHI")
WRITE, ERASE, INVERT, REFRESH = 0x10, 0x20, 0x30, 0x40


class Paper:
    def __init__(self, stream, width=384, height=224):
        self.stream = stream
        self.width, self.height = width, height
        stream.write(MAGIC + struct.pack("<HH", width, height))

    def _send(self, operation, x=0, y=0, width=0, height=0, data=b""):
        self.stream.write(RECORD.pack(operation, x, y, width, height, len(data)) + data)

    def _rectangle(self, x, y, width, height):
        if not (0 <= x < self.width and 0 <= y < self.height and
                0 < width <= self.width - x and 0 < height <= self.height - y):
            raise ValueError("Rectangle outside panel")

    def write(self, x, y, width, height, packed_rows):
        self._rectangle(x, y, width, height)
        if len(packed_rows) != ((width + 7) // 8) * height:
            raise ValueError("Incorrect pixel count")
        self._send(WRITE, x, y, width, height, packed_rows)

    def erase(self, x, y, width, height):
        self._rectangle(x, y, width, height)
        self._send(ERASE, x, y, width, height)

    def invert(self, x, y, width, height):
        self._rectangle(x, y, width, height)
        self._send(INVERT, x, y, width, height)

    def refresh(self):
        self._send(REFRESH)
