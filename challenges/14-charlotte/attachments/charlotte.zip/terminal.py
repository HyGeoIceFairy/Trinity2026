"""A closed archive-terminal simulation. Roles affect game records only."""
from dataclasses import dataclass


DOCUMENTS = {"duty": "值班记录", "summer": "封存的夏日观察记录"}
TEXT = {"duty": "今日值班：整理目录，检查电子终端。", "summer": "封存的夏日观察记录已送达。"}
DELIVERY_DELAY = 6
LEASE_LENGTH = 5
MAX_JOBS = 12


class InvalidAction(ValueError):
    pass


@dataclass
class Job:
    number: int
    document: str
    mode: str
    owner: str
    actor_snapshot: str
    ready_at: int
    status: str = "waiting"
    received: bool = False


class Terminal:
    """One replay, one temporary identity, one personal mailbox.

    Terminal policy: after a temporary identity is returned or expires,
    its permission must no longer be used, including by waiting tasks.
    The clock advances only through the advance action, never wall time.
    """

    def __init__(self):
        self.tick = 0
        self.owner = "yuu"
        self.borrowed = False
        self.lease_until = 0
        self.jobs = []
        self.won = False

    @property
    def actor(self):
        return "archivist" if self.tick < self.lease_until else self.owner

    @staticmethod
    def permitted(actor, document):
        return document == "duty" or actor == "archivist"

    def act(self, request):
        if not isinstance(request, dict) or not isinstance(request.get("action"), str):
            raise InvalidAction("请求需要 action。")
        action = request["action"]
        fields = {"borrow": {"action"}, "return": {"action"},
                  "advance": {"action", "seconds"}, "queue": {"action", "document", "mode"},
                  "receive": {"action", "job"}, "reset": {"action"}}
        if action not in fields or set(request) != fields[action]:
            raise InvalidAction("操作或参数不正确。")
        if action == "reset":
            self.__init__()
        elif action == "borrow":
            if self.borrowed:
                raise InvalidAction("本次回放只能借用一次；可重新开始。")
            self.borrowed = True
            self.lease_until = self.tick + LEASE_LENGTH
        elif action == "return":
            if self.actor == self.owner:
                raise InvalidAction("当前已经是有宇。")
            self.lease_until = self.tick
        elif action == "advance":
            seconds = request["seconds"]
            if type(seconds) is not int or not 1 <= seconds <= 12 or self.tick + seconds > 120:
                raise InvalidAction("每次前进 1—12 秒，每次回放最多 120 秒。")
            for _ in range(seconds):
                self.tick += 1
                self._process()
        elif action == "queue":
            document, mode = request["document"], request["mode"]
            if not isinstance(document, str) or document not in DOCUMENTS or mode not in ("preview", "copy"):
                raise InvalidAction("请选择存在的档案与处理方式。")
            if len(self.jobs) >= MAX_JOBS:
                raise InvalidAction("本次回放的任务已满；可重新开始。")
            if not self.permitted(self.actor, document):
                raise InvalidAction("提交时的操作者无权访问这份档案。")
            self.jobs.append(Job(len(self.jobs) + 1, document, mode, self.owner,
                                 self.actor, self.tick + DELIVERY_DELAY))
        elif action == "receive":
            number = request["job"]
            if type(number) is not int or not 1 <= number <= len(self.jobs):
                raise InvalidAction("任务不存在。")
            job = self.jobs[number - 1]
            if job.status != "ready" or job.mode != "copy" or job.owner != self.owner:
                raise InvalidAction("收件箱中没有这份已完成的誊录。")
            job.received = True
            if job.document == "summer":
                self.won = True
        return self.view()

    def _process(self):
        for job in self.jobs:
            if job.status != "waiting" or self.tick < job.ready_at:
                continue
            # Preview uses the live operator; copying follows its work order.
            operator = self.actor if job.mode == "preview" else job.actor_snapshot
            job.status = "ready" if self.permitted(operator, job.document) else "denied"

    def view(self):
        return {"tick": self.tick, "actor": self.actor, "owner": self.owner,
                "remaining": max(0, self.lease_until - self.tick),
                "borrow_available": not self.borrowed, "won": self.won,
                "mail": [TEXT[j.document] for j in self.jobs if j.received],
                "jobs": [{"id": j.number, "document": j.document, "mode": j.mode,
                          "owner": j.owner, "ready_at": j.ready_at, "status": j.status,
                          "preview": TEXT[j.document] if j.mode == "preview" and j.status == "ready" else "",
                          "received": j.received} for j in self.jobs]}
