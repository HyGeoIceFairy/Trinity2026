/*
 * refrain - an after-school replay recorder.
 *
 * Build (Linux x86-64, static musl):
 *   zig cc -target x86_64-linux-musl -std=c11 -O0 -fno-omit-frame-pointer \
 *          -fno-ident -Wall -Wextra -static -Wl,--build-id=none refrain.c -o refrain
 *
 * The ending reads one line from /flag.  For local testing only, set
 * REFRAIN_FLAG_FILE to a different path.
 */
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define POOL_SLOTS 8
#define NOTE_CAP 48
#define MAX_NOTES 5
#define MAX_FAVORITES 2
#define LINE_CAP 128
#define SCENE_STAMP UINT64_C(0x5245465241494e)

struct Note {
    uint32_t length, capacity;
    char text[NOTE_CAP];
    struct Note *next_free;
};

struct Scene {
    uint32_t leave_ok, round;
    char place[8], memo[40];
    uint64_t stamp;
};

union slot {
    struct Note note;
    struct Scene scene;
};

_Static_assert(sizeof(struct Note) == 64, "Note must fit one pool slot");
_Static_assert(sizeof(struct Scene) == 64, "Scene must fit one pool slot");

static union slot pool[POOL_SLOTS];
static union slot *free_slots, *scene_slot;
static union slot *notes[MAX_NOTES], *favorites[MAX_FAVORITES];
static size_t note_count;
static uint32_t day = 1;

static void pool_free(union slot *slot)
{
    if (slot == NULL)
        return;
    slot->note.next_free = free_slots == NULL ? NULL : &free_slots->note;
    free_slots = slot;
}

static union slot *pool_alloc(void)
{
    union slot *slot = free_slots;
    if (slot != NULL)
        free_slots = slot->note.next_free == NULL ? NULL : (union slot *)slot->note.next_free;
    return slot;
}

static void pool_init(void)
{
    for (int index = POOL_SLOTS - 1; index >= 0; index--)
        pool_free(&pool[index]);
}

/* 0 = line read, 1 = too long, 2 = embedded NUL, -1 = end of input. */
static int read_line(char *buffer, size_t size)
{
    size_t length = 0;
    int byte, too_long = 0, has_nul = 0;
    while ((byte = getchar()) != EOF && byte != '\n') {
        if (byte == '\0') {
            has_nul = 1;
        } else if (length + 1 < size) {
            buffer[length++] = (char)byte;
        } else {
            too_long = 1;
        }
    }
    buffer[length] = '\0';
    if (byte == EOF && length == 0 && !too_long && !has_nul)
        return -1;
    if (length > 0 && buffer[length - 1] == '\r')
        buffer[--length] = '\0';
    return has_nul ? 2 : too_long;
}

static int read_number(const char *prompt, unsigned *value)
{
    char line[32];
    fputs(prompt, stdout);
    fflush(stdout);
    int status = read_line(line, sizeof line);
    if (status < 0)
        return -1;
    if (status == 2) {
        puts("输入中不能包含空字符。");
        return 0;
    }
    if (status > 0) {
        puts("输入过长。");
        return 0;
    }
    if (line[0] == '\0')
        return 0;
    uint32_t parsed = 0;
    for (size_t index = 0; line[index] != '\0'; index++) {
        unsigned digit = (unsigned char)line[index] - (unsigned)'0';
        if (digit > 9 || parsed > (UINT32_MAX - digit) / 10) {
            puts("请输入一个编号。");
            return 0;
        }
        parsed = parsed * 10 + digit;
    }
    *value = (unsigned)parsed;
    return 1;
}

static int read_text(const char *prompt, char *buffer, size_t capacity, int empty_ok)
{
    char line[LINE_CAP];
    fputs(prompt, stdout);
    fflush(stdout);
    int status = read_line(line, sizeof line);
    if (status < 0)
        return -1;
    if (status == 2) {
        puts("输入中不能包含空字符。");
        return 0;
    }
    size_t length = strlen(line);
    if (status > 0 || length >= capacity) {
        puts("这句话太长了。");
        return 0;
    }
    if (length == 0) {
        if (!empty_ok)
            puts("空白的一句话不会留下任何东西。");
        return 0;
    }
    memcpy(buffer, line, length + 1);
    return 1;
}

static void open_scene(uint32_t round)
{
    struct Scene *scene = &scene_slot->scene;
    scene->leave_ok = 0;
    scene->round = round;
    snprintf(scene->place, sizeof scene->place, "校门");
    snprintf(scene->memo, sizeof scene->memo, "傍晚的风吹过操场。");
    scene->stamp = SCENE_STAMP;
}

static void show_scene(void)
{
    const struct Scene *scene = &scene_slot->scene;
    printf("第 %u 次放学后\n地点：%.8s\n留言：%.40s\n出发许可：%s\n",
           scene->round, scene->place, scene->memo,
           scene->leave_ok == 0 ? "尚未取得" : "已取得");
}

static void write_note(void)
{
    if (note_count == MAX_NOTES) {
        puts("今天的留言已经写满了。");
        return;
    }
    char text[NOTE_CAP];
    if (read_text("留言内容：", text, sizeof text, 0) != 1)
        return;
    union slot *slot = pool_alloc();
    if (slot == NULL) {
        puts("没有空位了。");
        return;
    }
    notes[note_count++] = slot;
    slot->note.length = (uint32_t)strlen(text);
    slot->note.capacity = NOTE_CAP;
    memcpy(slot->note.text, text, slot->note.length + 1);
    puts("留言写好了。");
}

static void favorite_note(void)
{
    if (note_count == 0) {
        puts("今天还没有留言。");
        return;
    }
    size_t target = MAX_FAVORITES;
    for (size_t index = 0; index < MAX_FAVORITES; index++)
        if (favorites[index] == NULL) {
            target = index;
            break;
        }
    if (target == MAX_FAVORITES) {
        puts("收藏区已经满了。");
        return;
    }
    for (size_t index = 0; index < note_count; index++)
        printf("%zu. %.*s\n", index + 1, (int)notes[index]->note.length,
               notes[index]->note.text);
    unsigned choice = 0;
    if (read_number("收藏哪一条留言（0 返回）：", &choice) != 1 || choice == 0)
        return;
    if (choice > note_count) {
        puts("没有这条留言。");
        return;
    }
    favorites[target] = notes[choice - 1];
    printf("已收藏第 %u 条留言。\n", choice);
}

static void view_or_edit_favorite(void)
{
    if (favorites[0] == NULL && favorites[1] == NULL) {
        puts("收藏区还是空的。");
        return;
    }
    for (size_t index = 0; index < MAX_FAVORITES; index++) {
        printf("%zu. ", index + 1);
        if (favorites[index] == NULL) {
            puts("（空）");
            continue;
        }
        const struct Note *note = &favorites[index]->note;
        uint32_t used = note->length > NOTE_CAP ? NOTE_CAP : note->length;
        if (used == 0) {
            puts("（空白）");
        } else {
            fwrite(note->text, 1, used, stdout);
            putchar('\n');
        }
    }
    unsigned choice = 0;
    if (read_number("打开哪个收藏（0 返回）：", &choice) != 1 || choice == 0)
        return;
    if (choice > MAX_FAVORITES || favorites[choice - 1] == NULL) {
        puts("这个收藏是空的。");
        return;
    }
    char extra[NOTE_CAP];
    if (read_text("补上一句话（留空跳过）：", extra, sizeof extra, 1) != 1)
        return;
    struct Note *note = &favorites[choice - 1]->note;
    uint32_t used = note->length > NOTE_CAP - 1 ? NOTE_CAP - 1 : note->length;
    size_t added = strlen(extra);
    if (added > NOTE_CAP - 1 - used) {
        added = NOTE_CAP - 1 - used;
        /* Keep a complete UTF-8 prefix when the remaining space is short. */
        while (added > 0 && ((unsigned char)extra[added] & 0xc0) == 0x80)
            added--;
    }
    if (added == 0) {
        puts("收藏里放不下更多完整的文字了。");
        return;
    }
    memcpy(note->text + used, extra, added);
    note->length = used + (uint32_t)added;
    note->text[note->length] = '\0';
    puts("收藏内容更新了。");
}

static void restart_day(void)
{
    pool_free(scene_slot);
    for (size_t index = 0; index < note_count; index++)
        pool_free(notes[index]);
    note_count = 0;
    scene_slot = pool_alloc();
    if (scene_slot == NULL) {
        puts("回放器无法继续。");
        exit(1);
    }
    open_scene(++day);
    puts("这一天重新开始了。");
}

static void end_replay(void)
{
    if (scene_slot->scene.leave_ok == 0) {
        puts("还没有得到出发许可。");
        return;
    }
    const char *path = getenv("REFRAIN_FLAG_FILE");
    if (path == NULL || path[0] == '\0')
        path = "/flag";
    FILE *file = fopen(path, "r");
    char line[256];
    if (file == NULL || fgets(line, sizeof line, file) == NULL) {
        if (file != NULL)
            fclose(file);
        puts("结局记录缺失。");
        return;
    }
    fclose(file);
    line[strcspn(line, "\r\n")] = '\0';
    printf("……回放终于走到了结尾。\n%s\n", line);
}

int main(void)
{
    setvbuf(stdin, NULL, _IONBF, 0);
    setvbuf(stdout, NULL, _IONBF, 0);
    pool_init();
    scene_slot = pool_alloc();
    if (scene_slot == NULL)
        return 1;
    open_scene(day);
    for (;;) {
        puts("\n放学后回放器\n1. 写留言\n2. 收藏留言\n3. 查看或修改收藏\n"
             "4. 重新开始这一天\n5. 查看当前场景\n6. 尝试结束回放\n0. 离开");
        unsigned choice = 0;
        int result = read_number("选择：", &choice);
        if (result < 0)
            break;
        if (result == 0)
            continue;
        switch (choice) {
        case 0: puts("回放器关闭了。"); return 0;
        case 1: write_note(); break;
        case 2: favorite_note(); break;
        case 3: view_or_edit_favorite(); break;
        case 4: restart_day(); break;
        case 5: show_scene(); break;
        case 6: end_replay(); break;
        default: puts("没有这个选项。"); break;
        }
    }
    puts("回放器关闭了。");
    return 0;
}
