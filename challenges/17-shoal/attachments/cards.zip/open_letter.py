"""Open the letter using 64 point:island entries in walking order."""
from pathlib import Path
import argparse,hashlib,hmac,json,re,struct


def open_letter(record,letter):
    if len(record)!=64 or any(not isinstance(item,(list,tuple)) or len(item)!=2 or any(type(v) is not int for v in item) for item in record):
        raise ValueError('Enter 64 point:island pairs')
    ids=[i for i,g in record];groups={g for i,g in record if g!=0}
    if set(ids)!=set(range(1,65)) or ids[0]!=1 or len(groups)!=4 or any(not 0<=g<=64 for i,g in record):
        raise ValueError('Use each point 1..64 once, starting at 1, and exactly four islands (plus 0 for submerged points)')
    if any(min(i for i,other in record if other==g)!=g for g in groups):
        raise ValueError('Name each island by its smallest point number')
    material=','.join(f'{i:02d}:{g:02d}' for i,g in record).encode('ascii')
    key=hashlib.sha256(b'shoal-tide-v3\0'+material).digest()
    if letter.get('version')!=1:raise ValueError('Unsupported letter')
    cipher=bytes.fromhex(letter['ciphertext']);tag=bytes.fromhex(letter['tag'])
    if not hmac.compare_digest(tag,hmac.digest(key,b'trinity-sealed-v1\0'+cipher,'sha256')):
        raise ValueError('The walking order does not open the letter')
    stream=b''.join(hashlib.sha256(key+struct.pack('<I',i)).digest() for i in range((len(cipher)+31)//32))
    return bytes(a^b for a,b in zip(cipher,stream)).decode('ascii')


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('order',nargs='?',help='comma-separated point:island pairs');p.add_argument('--file',type=Path);p.add_argument('--letter',type=Path,default=Path(__file__).with_name('letter.json'));a=p.parse_args()
    if bool(a.order)==bool(a.file):p.error('Supply numbers or --file, but not both')
    text=a.file.read_text(encoding='utf-8-sig') if a.file else a.order
    if re.search(r'[^0-9:,\s]',text):p.error('Use point:island pairs separated by commas or spaces')
    try:
        record=[tuple(int(v) for v in s.split(':')) for s in re.split(r'[,\s]+',text.strip()) if s]
        print(open_letter(record,json.loads(a.letter.read_text(encoding='utf-8'))))
    except (ValueError,KeyError,TypeError) as error:p.exit(1,str(error)+'\n')


if __name__=='__main__':main()
