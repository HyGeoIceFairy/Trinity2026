"""Public deterministic evaluator for the fictional NPC/SSS photo model."""
from pathlib import Path
import argparse
import json
import zipfile

SIDE = 16
COUNT = SIDE * SIDE
HIDDEN = 8
MAX_CHANGED = 12
MAX_DELTA = 8


class InvalidSample(ValueError):
    pass


def _object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON field")
        result[key] = value
    return result


def _constant(value):
    raise ValueError("Non-finite JSON value")


def decode_json(raw):
    return json.loads(raw.decode("utf-8"), object_pairs_hook=_object, parse_constant=_constant)


def load_bundle(filename):
    with zipfile.ZipFile(filename) as archive:
        names = archive.namelist()
        if len(names) != 3 or set(names) != {"model.json", "memory.json", "evaluate.py"}:
            raise ValueError("Unexpected model bundle")
        if any(info.file_size > 65536 for info in archive.infolist()):
            raise ValueError("Model bundle too large")
        model = decode_json(archive.read("model.json"))
        memory = decode_json(archive.read("memory.json"))
    return validate_model(model, memory)


def validate_model(model, memory):
    if not isinstance(model, dict) or model.get("format") != "ab-relu-int-v2":
        raise ValueError("Unsupported model")
    def vector(value, length, bound):
        return (isinstance(value, list) and len(value) == length and
                all(type(item) is int and abs(item) <= bound for item in value))
    weights = model.get("hidden_weights")
    if (type(model.get("width")) is not int or model["width"] != SIDE or
            type(model.get("height")) is not int or model["height"] != SIDE or
            type(model.get("hidden_units")) is not int or model["hidden_units"] != HIDDEN or
            type(model.get("output_bias")) is not int or abs(model["output_bias"]) > 100000000 or
            not isinstance(weights, list) or len(weights) != HIDDEN or
            not all(vector(row, COUNT, 4) for row in weights) or
            not vector(model.get("hidden_bias"), HIDDEN, 100000000) or
            not vector(model.get("output_weights"), HIDDEN, 8) or
            model.get("labels") != ["NPC", "SSS"]):
        raise ValueError("Invalid model parameters")
    if not isinstance(memory, dict) or set(memory) != {"pixels", "limits", "target"}:
        raise ValueError("Invalid reference document")
    validate_pixels(memory["pixels"])
    if memory["target"] != "SSS" or memory["limits"] != {
            "max_changed": MAX_CHANGED, "max_delta": MAX_DELTA, "preserve_sum": True}:
        raise ValueError("Unsupported sample rules")
    if predict(memory["pixels"], model)["label"] != "NPC":
        raise ValueError("Reference must start in NPC class")
    return model, memory


def validate_pixels(pixels):
    if not isinstance(pixels, list) or len(pixels) != COUNT:
        raise InvalidSample("pixels must contain exactly 256 values")
    if any(type(p) is not int or not 0 <= p <= 255 for p in pixels):
        raise InvalidSample("Every pixel must be an integer from 0 to 255")


def predict(pixels, model):
    hidden = [max(0, bias + sum(w * p for w, p in zip(row, pixels)))
              for row, bias in zip(model["hidden_weights"], model["hidden_bias"])]
    score = model["output_bias"] + sum(w * h for w, h in zip(model["output_weights"], hidden))
    return {"label": "SSS" if score >= 0 else "NPC", "score": score}


def evaluate(candidate, model, memory):
    if not isinstance(candidate, dict) or set(candidate) != {"pixels"}:
        raise InvalidSample("Submit one JSON object containing only pixels")
    pixels = candidate["pixels"]
    validate_pixels(pixels)
    delta = [p - r for p, r in zip(pixels, memory["pixels"])]
    changed = sum(d != 0 for d in delta)
    linf = max(abs(d) for d in delta)
    brightness_delta = sum(delta)
    if changed > MAX_CHANGED:
        raise InvalidSample("More than 12 pixels changed")
    if linf > MAX_DELTA:
        raise InvalidSample("A pixel changed by more than 8")
    if brightness_delta != 0:
        raise InvalidSample("Total brightness changed")
    result = predict(pixels, model)
    result.update(accepted=result["label"] == memory["target"], changed=changed,
                  max_delta=linf, brightness_delta=brightness_delta)
    return result


def main():
    parser = argparse.ArgumentParser(description="Check one photo against the bundled NPC/SSS model")
    parser.add_argument("sample", type=Path)
    parser.add_argument("--bundle", type=Path, help="Use the ZIP instead of the adjacent model files")
    args = parser.parse_args()
    try:
        if args.sample.stat().st_size > 8192:
            raise ValueError("Sample is too large")
        if args.bundle:
            model, memory = load_bundle(args.bundle)
        else:
            folder = Path(__file__).resolve().parent
            model, memory = validate_model(decode_json((folder / "model.json").read_bytes()),
                                           decode_json((folder / "memory.json").read_bytes()))
        result = evaluate(decode_json(args.sample.read_bytes()), model, memory)
    except (ValueError, OSError, zipfile.BadZipFile, RecursionError) as error:
        parser.exit(2, f"Invalid input: {error}\n")
    print(json.dumps(result, ensure_ascii=False))
    return 0 if result["accepted"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
